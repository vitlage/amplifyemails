<!DOCTYPE html>
<html>
    <head>
        <title>404</title>
    </head>
    <body>
        <div class="container">
            <div class="content">
                <h1>404 - Not found</h1>
                <p>Go back to your <a href="{{ url('/') }}">Homepage</a></p>
            </div>
        </div>
    </body>
</html>
