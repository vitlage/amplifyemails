<li class="d-flex align-items-center text-white">
    <div class="d-inline-block d-flex mr-auto align-items-center ml-1">
        <i class="material-icons-outlined me-2 fs-5 text-warning">verified_user</i>
        <span class="my-0 me-2 pl-1">{{ trans('messages.subscription.secure_checkout') }}</span>
    </div>
</li>