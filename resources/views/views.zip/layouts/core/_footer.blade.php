<div class="footer text-muted mt-5 py-3 small">
    <p class="mb-0">{!! trans('messages.copy_right') !!}</p>
</div>