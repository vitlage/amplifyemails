<html lang="en">
<head>
</head>

<body>

	@yield('content')

</body>
</html>
