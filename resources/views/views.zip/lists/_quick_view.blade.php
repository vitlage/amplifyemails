@if (isset($list->id))
    @include("lists._stat")
@endif
@include("lists._growth_chart")