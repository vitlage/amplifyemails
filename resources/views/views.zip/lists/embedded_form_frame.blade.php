@extends('layouts.core.none')

@section('content')
    <div style="padding:20px">
        @include("lists._embedded_form_content")
    </div>
@endsection
