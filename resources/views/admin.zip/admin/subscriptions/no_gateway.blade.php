<div class="alert alert-danger">
    {!! trans('messages.admin.no_primary_payment', [
        'link' => action('Admin\PaymentController@index'),
    ]) !!}
</div>