{!! $template->getPreviewContent() !!}
