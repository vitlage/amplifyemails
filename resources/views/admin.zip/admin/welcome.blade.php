@extends('layouts.core.backend')

@section('content')
    <br />
    <h1>Welcome</h1>
@endsection
